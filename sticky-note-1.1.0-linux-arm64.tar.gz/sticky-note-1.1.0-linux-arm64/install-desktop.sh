#!/bin/bash
# 可选：把 sticky note 加入应用菜单（不需要 root）
set -e
DIR="$(cd "$(dirname "$0")" && pwd)"
APPS="$HOME/.local/share/applications"
mkdir -p "$APPS"
cat > "$APPS/sticky-note.desktop" <<DESK
[Desktop Entry]
Type=Application
Name=sticky note
Comment=简洁高效的本地便签
Exec="$DIR/todo-list" %U
Terminal=false
Icon=$DIR/logo.png
StartupWMClass=sticky note
Categories=Office;
DESK
if command -v update-desktop-database >/dev/null 2>&1; then update-desktop-database "$APPS" || true; fi
echo "已加入应用菜单: sticky note"
