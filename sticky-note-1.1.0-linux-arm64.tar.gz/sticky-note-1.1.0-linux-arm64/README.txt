sticky note 1.1.0 免安装版
================================

运行:   ./sticky-note.sh           （或直接 ./todo-list）
菜单:   ./install-desktop.sh       （可选，写入 ~/.local/share/applications）

便签数据保存在 ~/.config/todo-list，与其他版本共用。
配置文件: ~/.config/todo-list/settings.json
