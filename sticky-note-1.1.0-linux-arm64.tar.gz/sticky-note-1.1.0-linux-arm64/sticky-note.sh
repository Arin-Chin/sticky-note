#!/bin/bash
# 启动脚本：在解压目录就地运行
cd "$(dirname "$0")"
exec ./todo-list "$@"
